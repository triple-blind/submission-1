#!/usr/bin/env python2

from triton     import *
from triton.ast import *
from pintool    import *

TAINTING_SIZE = 8

def tainting(threadId):
    rdi = getCurrentRegisterValue(REG.RDI) # argc
    rsi = getCurrentRegisterValue(REG.RSI) # argv

    while rdi > 1:
        argv = getCurrentMemoryValue(rsi + ((rdi-1) * CPUSIZE.QWORD), CPUSIZE.QWORD)
        offset = 0
        while offset != TAINTING_SIZE:
            taintMemory(argv + offset)
            concreteValue = getCurrentMemoryValue(argv + offset)
            convertMemoryToSymbolicVariable(MemoryAccess(argv + offset, CPUSIZE.BYTE, concreteValue))
            offset += 1
        print '[+] %02d bytes tainted from the argv[%d] (%#x) pointer' %(offset, rdi-1, argv)
        rdi -= 1

    return

def taint2(threadId):
    print 'called'
    #esp = getCurrentRegisterValue(REG.RSP) - 0x14
    #argv = getCurrentMemoryValue(esp, 4)
    #uinta = getCurrentMemoryValue(argv, 4)
    #print '%x    %x' %(esp, argv)
    convertRegisterToSymbolicVariable(REG.EDI)
    #convertMemoryToSymbolicVariable(MemoryAccess(esp, CPUSIZE.QWORD, argv))
    return


def fini():
    pco = getPathConstraints()
    for pc in pco:
        print "0x%x"%(pc.getTakenAddress())
        if pc.isMultipleBranches():
            b1   =  pc.getBranchConstraints()[0]['constraint']
            b2   =  pc.getBranchConstraints()[1]['constraint']
            #print b1
            #print b2
            seed = list()

            # Branch 1
            models  = getModel(assert_(b1))
            for k, v in models.items():
                print v
                seed.append(v)

            # Branch 2
            models  = getModel(assert_(b2))
            for k, v in models.items():
                print v
                seed.append(v)

            #if seed:
            #    print 'B1: %s (%c)  |  B2: %s (%c)' %(seed[0], chr(seed[0].getValue()), seed[1], chr(seed[1].getValue()))
    return

def cb_before(inst):
    print inst
    for expr in inst.getSymbolicExpressions():
        print '\t', expr
    return

if __name__ == '__main__':
    # Define the architecture
    setArchitecture(ARCH.X86_64)

    # Start the symbolic analysis from the 'main' function
    startAnalysisFromSymbol('main')

    # Align the memory
    enableSymbolicOptimization(OPTIMIZATION.ALIGNED_MEMORY, True)
    enableSymbolicOptimization(OPTIMIZATION.ONLY_ON_TAINTED, True)

    # Only perform the symbolic execution on the target binary
    #setupImageWhitelist(['sample47'])

    # Add callbacks
    insertCall(tainting, INSERT_POINT.ROUTINE_ENTRY, 'main')
    #insertCall(taint2, INSERT_POINT.ROUTINE_ENTRY, 'tigress_obf')
    #insertCall(cb_before,   INSERT_POINT.BEFORE)
    insertCall(fini,     INSERT_POINT.FINI)

    # Run the instrumentation - Never returns
    runProgram()

