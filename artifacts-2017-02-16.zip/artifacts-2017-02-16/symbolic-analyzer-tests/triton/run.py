from multiprocessing.pool import ThreadPool
import signal
import time
from subprocess import Popen, PIPE


def worker(name):
	#try: 
	print 'sample'+str(name)
	output = open('./run-outputs-seq/sample'+str(name), 'w')
	pr = Popen(['time','timeout', '3h', '../triton', './path_constraint.py', './REGULAR/sample'+str(name), 'xxxx'], stdout=output, stderr=PIPE)
	stdout, stderr = pr.communicate()
	output.close()
	#except Exception as inst:
		#print str(name)+': Exception: ' + str(type(inst))


# number of threads
p = ThreadPool(8)
# the followin will create threads, running analysis on sample9, sample10, sampe11 ...
p.map(worker, [9,10,11,12,13,16,17])
