for f in ./output/triton/*
do
  echo $(basename $f)
  ../pin-2.14-71313-gcc.4.4.7-linux/pin -ifeellucky -t build/libpintool.so -script ./path_constraint.py -- $f xxxx > $(basename $f)
  #gcc $f -o $(basename $f ".c") -lpthread
done
