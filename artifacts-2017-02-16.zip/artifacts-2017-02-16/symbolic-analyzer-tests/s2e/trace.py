#!/usr/bin/python

##############################################
# put the name of executables that need to 
# be analyzed in a file, e.g., commands.txt
# run the script: python trace.py commands.txt
# Take a look at the paths when launching the 
# qemu process. The script assumes qemu resumes
# the 'samples2' disk snapshot.
##############################################

import subprocess as sp
import os, sys, time

import signal
class Alarm(Exception):
    pass

def alarm_handler(signum, frame):
    raise Alarm

outPutPath=''
FNULL = open(os.devnull, 'w')
numCores = 0
s2e_output_dir = 's2e_out_0'


if __name__ == "__main__":
	if len(sys.argv) < 3:
		print 'Usage: ' + sys.argv[0]+' commandFiles resultPath numCores portnumber'
		exit(0)
	commandFileName = sys.argv[1]
	port = 0
	sample_num = port
	port = port+4444
	print numCores

	if not os.path.exists(outPutPath):
		os.makedirs(outPutPath)

	commandFile = open(commandFileName, 'r')
	commands = commandFile.readlines()
	numCommands = len(commands)
	processed = 1
	for line in commands:
		log_name = 'log'+str(sample_num)
		log_file = open(log_name, 'w')
		execName = line.split()[0]
		print 'Start processing of '+execName+' command '+str(processed)+' of '+str(numCommands)+' at: '+time.ctime()
		processed = processed + 1
		log_file.write('*********************** Startet '+ execName +' at '+time.ctime()+'***********************\n')
		log_file.write('command ran in guest os:'+line+'\n\n\n')
		log_file.flush()
		numCoresArg = ''
		try:	
			qemu = sp.Popen(['build/qemu-release/x86_64-s2e-softmmu/qemu-system-x86_64', '-hda', 'vms/debian.raw.s2e', '-net', 'none', '-monitor', 'telnet:localhost:'+str(port)+',server,nowait', '-loadvm', 'samples2', '-s2e-config-file', 'vms/debian-config.lua', '-nographic'], shell=False, stdout=log_file, stderr=log_file)
				
		except Exception as inst:
			print 'Unable to launch qemu process!'
			print type(inst)
			continue
		signal.signal(signal.SIGALRM, alarm_handler)
		signal.alarm(12*60*60)  # 4 hours timeout
		

		try:	
			time.sleep(20)
			log_file.flush()
			try:
				monitor = sp.Popen(['telnet', 'localhost', str(port)], shell=False, stdout=log_file, stderr=log_file, stdin=sp.PIPE)
			except Exception as inst:
				print 'Unable to telnet!'
                	        print type(inst)
                        	continue

			sendkeyStr = ''
			monitor.stdin.write('sendkey dot\n')
			monitor.stdin.write('sendkey slash\n')
			for c in line:
				if c.isspace():
					monitor.stdin.write('sendkey spc\n')
				elif c == '_':
					monitor.stdin.write('sendkey shift-minus\n')
				elif c == '.':
					monitor.stdin.write('sendkey dot\n')
				else:
					monitor.stdin.write('sendkey '+c+'\n')
			monitor.stdin.write('sendkey ret\n')
			stdoutdata, stderrdata = qemu.communicate()
			print stdoutdata
			signal.alarm(0)  # reset the alarm
		except Alarm:
			print "\tTaking too long!"
			log_file.write('\n\n***************************** processed killed: timed out at '+time.ctime()+' ************************');
			pids = [qemu.pid]
			for pid in pids:
			        # process might have died before getting to this line
			        # so wrap to avoid OSError: no such process
				try: 
					os.kill(pid, signal.SIGKILL)
				except OSError:
					pass
		print 'done'

