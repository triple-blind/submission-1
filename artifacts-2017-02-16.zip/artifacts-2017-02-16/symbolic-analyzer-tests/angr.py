import angr, claripy, simuvex

def path1(path):
	try:
		return 'SUCCESS' in path.state.posix.dumps(1)
	except:
		return False

def path2(path):
	try:
		return 'FAILURE' in path.state.posix.dumps(1)
	except:
		return False

sample = './sample17'

print sample

project=angr.Project(sample)
argv=[project.filename]

sym_i = claripy.BVS('input', 32)
argv.append(sym_i)

state = project.factory.entry_state(args=argv)

for b in range(0,4):
	state.se.add(argv[1][(b*8+7):(b*8)] >= 0x30)
	state.se.add(argv[1][(b*8+7):(b*8)] <= 0x7a)

#pg = project.factory.path_group(state, veritesting=True)
pg = project.factory.path_group(state)

pg.explore(find=path2)
pg.explore(find=path1)

print sample + " found " + str(len(pg.found)) + "/2 paths"

for p in pg.found:
	print p.state.posix.dumps(1)
	print p.state.se.any_str(sym_i)

print sample + " errored " + str(len(pg.errored))

print sample + " deadended " + str(len(pg.deadended))


