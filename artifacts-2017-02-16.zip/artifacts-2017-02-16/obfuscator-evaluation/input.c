#include "apple.h"
#include <stdio.h>
#include<stdlib.h>

#ifdef JIT
#include "jitter-amd64.c"
#endif
#ifdef S2E
#include "s2e.h"
#define disable_forking() s2e_disable_forking()
#define enable_forking() s2e_enable_forking()
#define make_symbolic(X, Y, Z) s2e_make_symbolic(X, Y, Z)
#define terminate_path(X) s2e_kill_state(0, X);

#else

#define disable_forking() (void)0
#define enable_forking() (void)0
#define make_symbolic(...) (void)0
#define terminate_path(X) (void)0
#endif

void tigress_init () {
}

int tigress_obf (unsigned int a) {
   unsigned int b;
   b = a;
   return b;
}

unsigned int a;
int main(int argc, char **argv){
   tigress_init();

#ifdef FUZZBALL
	printf("%p\n", &a);
#endif
    
	if(argc != 2) {
		printf("Usage: clear <secret>\n");
		return 1;
	}


#ifndef FUZZBALL
char* x = argv[1];
a = *(unsigned int*)x;
#endif
	make_symbolic(&a, sizeof(a), "secret");
       	unsigned int b;

	enable_forking();
        //the only part we need obfuscated
        b = tigress_obf(a);

       	if (b == 0x55787855) {
		disable_forking();
		printf("SUCCESS\n");
		terminate_path("path 1");
	} else {
		disable_forking();
        	printf("FAILURE\n");
		terminate_path("path 2");
	}
        return 0;
}

/*
    U = 01010101 4+4
    Z = 01011010 4+4
    x = 01111000 4+4
    l = 01101100 4+4
    ASCII UZxl = 0x555a786c
    ASCII UxxU = 0x55787855 (Palindromes ignore byteorder)
*/
