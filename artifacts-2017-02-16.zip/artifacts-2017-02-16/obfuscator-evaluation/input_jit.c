#include "apple.h"
#include<stdio.h>
#include<stdlib.h>
#include "jitter-amd64.c"

#ifdef S2E
#include "s2e.h"
#define disable_forking() s2e_disable_forking()
#define enable_forking() s2e_enable_forking()
#define make_symbolic(X, Y, Z) s2e_make_symbolic(X, Y, Z)
#define terminate_path(X) s2e_kill_state(0, X);

#else

#define disable_forking() (void)0
#define enable_forking() (void)0
#define make_symbolic(...) (void)0
#define terminate_path(X) (void)0
#endif

int a;
int main(int argc, char **argv){
	printf("%p\n", &a);
	if(argc != 2) {
		printf("Usage: clear <secret>\n");
		return 1;
	}

#ifndef FUZZBALL
       	a = atoi(argv[1]);
#endif
	make_symbolic(&a, sizeof(a), "secret");
       	int b;

	//the only part we need obfuscated
	b = a;

       	if (b == 10) {
		disable_forking();
		printf("a == 10\n");
		terminate_path("path 1");
	} else {
		disable_forking();
        	printf("a != 10\n");
		terminate_path("path 2");
	}
        return 0;
}
