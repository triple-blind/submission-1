
#include "apple.h"
#include<stdio.h>
#include<stdlib.h>
#include "../../../../bin/tigress-unstable/jitter-amd64.c"

int main(int argc, char** argv) {
   int f = 424242424;
   printf("f=%i\n", f);
}
