
$::cc        = "gcc";
$::cilbindir = $ENV{'TIGRESS_HOME'};
$::default_mode = "GNUCC";

